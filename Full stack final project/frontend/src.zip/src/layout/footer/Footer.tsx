
const Footer = () => {
  return (
    <footer>
      <p>&copy; {new Date().getFullYear()} Created By Pini Elbaum</p>
    </footer>
  )
}

export default Footer
